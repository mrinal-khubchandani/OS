#include "global.h"

void echo_call(char **args)
{
    printf("%s\n",args[1]);
}